ALTER TABLE `#__attachments` MODIFY `filename` VARCHAR(256) NOT NULL;
ALTER TABLE `#__attachments` MODIFY `filename_sys` VARCHAR(512) NOT NULL;
